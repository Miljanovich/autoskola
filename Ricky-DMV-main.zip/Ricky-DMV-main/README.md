# Ricky-DMV
Advanced DMV School | FiveM

# Preview
<img width="1920" alt="preview_dmv" src="https://github.com/R1CKY6/Ricky-DMV/assets/100082886/d901429f-3e7d-47e8-aee4-6d374ea75aa2">

# Dependecies
- esx_license
- oxmysql

# Features
- Custom UI
- Configurable
- Optimized (0.0ms idle)

# Installation
1. Drag Ricky-DMV in your resource folder
2. Setup config
3. Add `ensure Ricky-DMV` in your server.cfg
4. Start the server.

# Support
For any problem you can join in my discord for free support [Click Here](https://discord.gg/tHAbhd94vS)
